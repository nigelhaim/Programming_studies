let x;

// const num = new Number(5);

// x = num.toString().length;

// console.log(x);

const num = 500.2345;
// x = num.toString().length;
// x =  num.toFixed(1);
//x = num.toPrecision(4);
// x = num.toExpoential(1);
//x = Number.MAX_VALUE;
x = Number.MIN_VALUE;
console.log(x);