console.log("Hello world", 20, true);
//console can be used to debug
console.log(console); //Checks the console
console.error(console); //Displays as an error
console.warn(console); //Displays as a warning
console.assert("Alert");
//alert(console);

console.table({key: 'car', value: 'red'});

