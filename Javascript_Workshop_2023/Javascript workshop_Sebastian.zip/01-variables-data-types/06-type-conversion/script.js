//let amount = 'hello';
let amount = '50';
//Convert a string into number
//amount = parseInt(amount);
//amount = +amount;
//amount = Number(amount);

//Convert string into number
//amount = amount.toString();
//amount = String(amount);

//String to float
//amount = parseFloat(amount);

//Squareroot
//amount = Math.sqrt(-1);


//amount = 1 + NaN results to NaN

//amount = undefined + undefined results to undefined

//amount = 'undefined' / 3 results to NaN 

amount = 'Hello';

console.log(amount);

