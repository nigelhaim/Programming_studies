let x;
x = 5 + '5';//Concatonation
x = 5 * '5';//Multiply
x = 5 + Number('5');//Addition
x = 5 + null//Null == 0 
x = 5 + Number(false);// it is equal to 5 + 0 



console.log(x, typeof x);

