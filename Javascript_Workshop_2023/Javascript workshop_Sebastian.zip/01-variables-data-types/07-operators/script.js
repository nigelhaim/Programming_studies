// 1. Arithmetic Operators


// 2. Assignment Operators


// 3. Comparison Operators
//let x = 2 ** 3;
let x = 2 >= '2' ? 5:3;
console.log(x);