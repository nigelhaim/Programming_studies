let x = -25; 
//x = Math.sqrt(x);
// x = math.abs(x);
// x = math.round(x);
// x = math.floor(x);
// x = math.ceil(x);
// x = Math.pow(x,3);
//x = Math.min(x, 3, 5);
//x = Math.max(x, 3, 5);
x = Math.random()*10+1;
//Floor to remove decimal
console.log(x);
