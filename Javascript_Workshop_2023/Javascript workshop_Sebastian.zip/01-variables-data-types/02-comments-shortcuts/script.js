//Single line comment
//console.log("Hello");


/*

console.log("Hello");
console.log("Hello");
console.log("Hello");
console.log("Hello");

*/

//You can use highlight and ctrl + / on multi line comment 


