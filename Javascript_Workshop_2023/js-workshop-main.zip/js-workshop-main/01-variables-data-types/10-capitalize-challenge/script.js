// Create a new string called "myNewString" that holds the value of "Developer", using the value from "myString"
const myString = 'developer';